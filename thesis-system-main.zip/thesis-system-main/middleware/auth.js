// has access to request and response cycle and objects
const jwt = require('jsonwebtoken');
const config = require('config');


module.exports = function(req, res, next) {
  // Get token from headers
  const token = req.header('x-auth-token');

  // Check if no token
  if(!token) {
    return res.status(401).json({ msg: 'No token, authorization denied.'}); 
  }

  // Verify the token
  try {
    // if the token is valid
    const decoded = jwt.verify(token, config.get('jwtSecret'));

    req.user = decoded.user;
    next();
  } catch (err) {
    // if the token is not valid
    res.status(401).json({ msg: 'Token is not valid.' });
  }
};