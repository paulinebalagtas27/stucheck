import { Outlet } from 'react-router-dom';


// mga headers nern
// navbars

const Layout = () => {
  return (
    <main className = 'App'>
      <Outlet />
    </main>
  )
}

export default Layout;