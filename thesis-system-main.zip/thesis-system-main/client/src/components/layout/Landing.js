import React from 'react';
import { Link } from 'react-router-dom';

import './css/landing.css';
import 'bootstrap/dist/css/bootstrap.min.css';


export const LandingPage  = () => {
  return (
    <>
      <div className='landingContainer'>
        <div className='landingWrapper'>
          <div className="landingLeft"></div>
            <div className='landingRight'>
              <div className="landingRightWrapper">

                <div className='landingRightHeader'>

                  <img src='https://th.bing.com/th/id/OIP.6hFY8ITLNPbeGqHsB8b4OQHaHa?pid=ImgDet&rs=1'
                    alt='PUP Logo'
                    className='landingRightHeaderImage'
                  />

                  <p className='landingRightHeaderText'>
                    Hello, PUPian!
                  </p>

                  <p> Please click or tap your destination! </p>
                  
                </div>

                <div className='landingRightCenter'>
                
                  <Link to = "/studentLogin" className = "btn btn-primary" role = "button">
                    Student
                  </Link>

                  <Link to = "/facultyLogin" className = "btn btn-danger" role = "button">
                    Faculty
                  </Link>

                </div>

                <div className='landingBottom'>
                  
                  <p className='landingBottomText'>
                    By using this service, you understood and agree to the 
                    PUP Online Services <span className='landingBottomLink'>Terms of Use </span>
                    and <span className='landingBottomLink'>Privacy Statement</span>
                  </p>

                </div>
                
              </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default LandingPage;