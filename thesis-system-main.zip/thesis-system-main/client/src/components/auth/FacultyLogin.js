
import 'bootstrap/dist/css/bootstrap.min.css';

import React from 'react';

export const facultyLogin = () => {
  return <div>
    <h1> Faculty Login </h1>
  </div>;
};

export default facultyLogin;
