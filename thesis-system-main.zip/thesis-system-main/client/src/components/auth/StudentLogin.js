import React, {Fragment, useState} from 'react';

import './css/studentLogin.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const StudentLogin = () => {
  const [formData, setFromData] = useState({
    stud_num: '',
    pup_webmail: '',
    password: ''
  });

  const { stud_num, pup_webmail, password} = formData;

  const onChange = e =>
    setFromData({ ...formData, [e.target.name]: e.target.value });
  
  const onSubmit = async e => {
    e.preventDefault();
    console.log('Success!');
  };

  return(
    <Fragment>
      <div className = 'landingContainer'>
        <div className='landingWrapper'>
          <div className="landingLeft"></div>
            <div className='landingRight'> 
              <div className="landingRightWrapper">
                <div className='landingRightHeader'>

                    <img src='https://th.bing.com/th/id/OIP.6hFY8ITLNPbeGqHsB8b4OQHaHa?pid=ImgDet&rs=1'
                      alt='PUP Logo'
                      className='landingRightHeaderImage'
                    />

                    <p className='landingRightHeaderText'>
                      PUP-SIS Student Module
                    </p>

                    <p> Sign in to start your session! </p>

                    <div className='landingRightCenter'>

                      <form className = 'form' onSubmit = { e => onSubmit(e) }>

                        {/* Student Number */}
                        <div className = "form-group">
                          <input 
                            type = "text"
                            placeholder = 'Student Number'
                            name = 'stud_num'
                            value = {stud_num}
                            onChange = { e => onChange(e)}
                            minLength = '15'
                            required
                          />
                        </div>

                        {/* PUP Webmail */}
                        <div className = "form-group" >
                          <input
                            type = "email"
                            placeholder = 'Email'
                            name='pup_webmail'
                            value = {pup_webmail}
                            onChange = { e => onChange(e)}
                            required
                            
                          />
                        </div>

                        {/* Password */}
                        <div className = "form-group">
                          <input 
                            type = "password"
                            placeholder = 'Password'
                            name='password'
                            value = {password}
                            onChange = { e => onChange(e)}
                            minLength = '6'
                            required
                            />
                        </div>

                      <input type = 'submit' className = 'btn btn-primary btn-lg btn-block' value = 'Sign In' />
                      
                      <div className='landingBottom'>
                  
                        <p className='landingBottomText'>
                          By using this service, you understood and agree to the 
                          PUP Online Services <span className='landingBottomLink'>Terms of Use </span>
                          and <span className='landingBottomLink'>Privacy Statement.</span>
                        </p>

                      </div>

                      </form>

                    </div> 
                 </div>
              </div>
            </div>
        </div>
      </div>
    </Fragment>
  );
};


export default StudentLogin;
