import './App.css';

import { Routes, Route } from 'react-router-dom';

// screens from components
import Layout from './components/layout/Layout';

import Landing from './components/layout/Landing';
import StudentLogin from './components/auth/StudentLogin';
import FacultyLogin from './components/auth/FacultyLogin';

/* Redux
import { Provider } from 'react-redux;
import store from './store';
*/

function App () {

  return(
    //<Provider store = { store } >
      <Routes>
        <Route path = '/' element = { <Layout/> }>
          <Route path = '/' element = { <Landing/> } />

          {/* public routes */}
          <Route path = '/studentLogin' element = { <StudentLogin/> } />
          <Route path = '/facultyLogin' element = { <FacultyLogin/> } />

          {/* protected/private routes */ }

        </Route>
      </Routes>
    // </Provider>
  )
};


export default App;