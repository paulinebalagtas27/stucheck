const mongoose = require('mongoose');

const StudentProfileSchema = new mongoose.Schema({

  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'user'
  },

  name: {
    type: String,
    required: true
  },

  year: {
    type: Number,
    required: true,
  },

  section: {
    type: Number,
    required: true,
  },

  gender: {
    type: String,
    required: true,
    enum: ["Male", "Female"]
  },

  birthday: {
    type: Date,
    required: false //must be true
  },

  birthPlace: {
    type: String,
    required: false
  },

  phoneNum: {
    type: Number,
    required: false
  },

  address: {
    houseNo: {
        type: String,
        required: false // must be true
    },
    street: {
        type: String,
        required: false // must be true
    },
    baranggay: {
        type: String,
        required: false
    },
    municipality: {
        type: String,
        required: false
    },
    province: {
        type: String,
        required: false
    }
  },
  date: {
    type: Date,
    default: Date.now
  }
});


module.exports = StudentProfile = mongoose.model('studentProfile', StudentProfileSchema);