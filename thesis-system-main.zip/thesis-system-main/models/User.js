const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({

  stud_num: {
    type: String,
    required: true,
    unique: true
  },

  pup_webmail: {
    type: String,
    required: true,
    unique: true,
    match: [
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, "Please provide a valid email."
    ],
  },

  password: {
    type: String,
    required: true
    //select: false,
  },

  role: {
    type: String,
    required: true,
    enum: ['Student', 'Faculty', 'Supervisor']
  },

  date_logged: {
    type: Date,
    default: Date.now()
  }

});

module.exports = User = mongoose.model('user', UserSchema);