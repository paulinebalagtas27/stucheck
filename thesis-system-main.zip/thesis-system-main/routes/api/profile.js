const express = require('express');
const router = express.Router();
const auth = require('../../middleware/auth');
const { check, validationResult } = require('express-validator');

const Profile = require('../../models/StudentProfile');
const User = require('../../models/User');


// @route   GET api/profile/student (from token)
// @desc    Get current user's profile
// @access  Private
router.get('/me', auth, async (req, res) => {
  try {
    const profile = await Profile.findOne({ user: req.user.id })
      .populate('user', ['stud_num', 'role', 'pup_webmail']);

    if(!profile){
      return res.status(400).json({ msg: 'There is no profile for this user.' });
    }
      res.json(profile);

  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error.');
  }
});

// @route   POST api/profile
// @desc    CREATE or UPDATE a User Profile
// @access  Private

router.post('/', 
  [
    auth, // always initialized (laging nanjan)
      [check('stud_num', 'Student Identification Number is required.')
        .not()
        .isEmpty(),
      check('name', 'Full name is required.')
        .not()
        .isEmpty(),
      check('year', 'Year level is required.')
        .not()
        .isEmpty(),
      check('section', 'Section is required.')
        .not()
        .isEmpty()
      ]
  ], 
  async (req, res) => {
    const errors = validationResult(req);
    if(!errors.isEmpty()){
      return res.status(400).json({ errors: errors.array() });
    }

    const{
      name,
      year,
      section,
      gender,
      birthday,
      birthPlace,
      phoneNum,
      address
    } = req.body;

    // check if all is filled before adding to database
    // Build profile object
    const profileFields = {};

    profileFields.user = req.user.id;

    if(name) profileFields.name = name;
    if(year) profileFields.year = year;
    if(section) profileFields.section = section;
    if(gender) profileFields.gender = gender;
    if(birthday) profileFields.birthday = birthday;
    if(birthPlace) profileFields.birthPlace = birthPlace;
    if(phoneNum) profileFields.phoneNum = phoneNum;
    if(address) profileFields.address = address;

    // Update and Insert the data to the database
    try {

      let profile = await Profile.findOne({ user: req.user.id });

      // if there is a profile -> update
      if(profile) {
        profile = await Profile.findOneAndUpdate(
          { user: req.user.id }, 
          { $set: profileFields },
          { new: true }
        );

        return res.json(profile);
      }

      // if there's no profile -> create
      profile = new Profile(profileFields);

      await profile.save();
      res.json(profile);

    } catch (err) {
      console.error(err.message);
      res.status(500).send('Server Error.');
    }

  }
);

// @route   GET api/profile
// @desc    GET ALL STUDENT PROFILES
// @access  PUBLIC, auth(["Faculty", "Supervisor"]) supposedly, still public atm
router.get('/', async (req, res) => {
  try {

    const profiles = await Profile.find()
      .populate('user', ['stud_num', 'role', 'pup_webmail'] );

    res.json(profiles);

  } catch (err) {

    console.error(err.message);
    res.status(500).send('Server Error.');
  }

});

// @route   GET api/profile/users/:user_id
// @desc    GET PROFILE BY USER ID
// @access  PUBLIC, auth(["Faculty", "Supervisor"]) supposedly, still public atm
router.get('/user/:user_id', async (req, res) => {
  try {

    const profile = await Profile.findOne({ user: req.params.user_id })
      .populate('user', ['stud_num', 'role', 'pup_webmail'] );
    
    // check if there is a profile
    if(!profile) 
      return res.status(400).json({ msg: 'Profile not found.' });

    res.json(profile);

  } catch (err) {

    console.error(err.message);
    if(err.kind == 'ObjectId') {
      return res.status(400).json({ msg: 'Profile not found.' });
    }
    res.status(500).send('Server Error.');
  }
});

// @route   DELETE api/profile 
// @desc    Delete profile -> delete user din pwede 
// @access  Private

router.delete('/', async (req, res) => {
  try {

    // remove profile
    await Profile.findOneAndDelete({ user: req.user.id });

    // remove user
    // await Profile.findOneAndDelete({ _id: req.user.id });

    res.json({ msg: 'User deleted.' });

  } catch (err) {

    console.error(err.message);
    res.status(500).send('Server Error.');
  }

});


module.exports = router;