const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('config');

const { check, validationResult } = require('express-validator');

const User = require('../../models/User');


// @route   POST api/users
// @desc    REGISTER User 
// @access  Public
router.post('/', 

  [
    check('stud_num', 'Student ID is required.')
      .isLength({ min: 15, max: 15})
      .not()
      .isEmpty(),
    check('pup_webmail', 'Please enter PUP webmail.').isEmail(),
    check('password', 'Please enter a password with 6 or more characters.').isLength({ min: 6 }),
    check('role', "Please choose a role.")
      .not()
      .isEmpty()
  ],  

  async(req, res) => {

    const errors = validationResult(req);

    // check for errors
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { stud_num, pup_webmail, password, role } = req.body;

    try {
      // check if user exists
      let user = await User.findOne({ stud_num, pup_webmail, role });

      // if there is no user
      if(user) {
        return res.status(400).json({ errors: [ {msg: 'User already exists.'} ] })
      }

      user = new User({
        stud_num,
        pup_webmail,
        password,
        role
      });

      // Encrypt passwrd using bcrypt
      const salt = await bcrypt.genSalt(10);
      user.password = await bcrypt.hash(password, salt);
      await user.save();

      // Return jsonwebtoken - once registered, direct to login
      const payload = {
        user: {
          id: user.num
        }
      }

      jwt.sign(
        payload, 
        config.get('jwtSecret'),
        // 1 hour = 3600
        { expiresIn: 3600000 }, 
        (err, token) => {
          if(err) throw err;
          res.json({token})
        }
      );
      
    } catch (err) {
      console.error(err.message);
      res.status(500).send('Server error.');
    }

});

module.exports = router;